# Ansible

This project will contain all the documentation related to Ansible Masterclass. I will keep adding data as i prepare my course. 

To clone this repository, 
1) Install git on your machine
2) Get the clone Url from gitlab
3) Do a git clone 